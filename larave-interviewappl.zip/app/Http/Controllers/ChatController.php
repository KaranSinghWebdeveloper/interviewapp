<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Events\MyEvent;
use App\Models\Message;
use Inertia\Inertia;

class ChatController extends Controller
{

    public function index()
    {
        $messages = Message::with('user:id,name')->where('content', '!=', '')->get()->map(function ($message) {
            return [
                'id' => $message->id,
                'user' => $message->user->name,
                'content' => $message->content,
            ];
        });

        return Inertia::render('Chat', [
            'messages' => $messages,
        ]);
    }

    public function send(Request $request)
    {
        // return auth()->id();
        // $request->validate([
        //     'content' => 'required|string|max:1000',
        // ]);
        // return 'helllo';

        $message = Message::create([

            'user_id' => auth()->id(),
            'content' => $request->content,
        ]);

        broadcast(new MyEvent([
            'user' => auth()->user()->name,
            'content' => $message->content,
        ]))->toOthers();

        $messages = Message::with('user:id,name')->get()->map(function ($message) {
            return [
                'id' => $message->id,
                'user' => $message->user->name,
                'content' => $message->content,
            ];
        });

        return Inertia::render('Chat', [
            'messages' => $messages,
        ]);
    }

    public function delete($id)
    {
        Message::where('id', $id)->delete();

        $messages = Message::with('user:id,name')->get()->map(function ($message) {
            return [
                'id' => $message->id,
                'user' => $message->user->name,
                'content' => $message->content,
            ];
        });

        return Inertia::render('Chat', [
            'messages' => $messages,
        ]);
    }
}
