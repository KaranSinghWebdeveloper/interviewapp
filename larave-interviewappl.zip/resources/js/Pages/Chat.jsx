import { useEffect, useState, useRef } from 'react';
import { useForm } from '@inertiajs/inertia-react';
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { Head } from '@inertiajs/react';

export default function Chat({ messages: initialMessages, auth }) {
    const [messages, setMessages] = useState(initialMessages || []);
    const messagesEndRef = useRef(null);

    // 👇 Initialize form state
    const { data, setData, post, reset } = useForm({
        content: '',
    });

    useEffect(() => {
        if (typeof Pusher !== 'undefined') {
            const pusher = new Pusher('bd20fe182fa15aca49ac', {
                broadcaster: 'pusher',
                cluster: 'ap2',
                forceTLS: true,
            });

            const channel = pusher.subscribe('my-channel');
            channel.bind('MyEvent', function (data) {
                const cleanData = data.data;
                setMessages(prevMessages => [...prevMessages, cleanData]);
            });

            return () => {
                pusher.unsubscribe('my-channel');
            };
        }
    }, []);

    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages]);

    const handleSend = (e) => {
        e.preventDefault();

        if (data.content.trim() === '') return;

        post('/messages', {
            onSuccess: (response) => {
                if (response.props.messages) {
                    setMessages(response.props.messages);
                }
            },
        });
        reset('content');
    };

    // const handleDelete = (messageId) => {
    //     console.log(messageId);
    //     post(`/messages/delete/${messageId}`, {
    //     });


    // };
    // console.log(messages);

    return (
        <AuthenticatedLayout
            header={
                <h2 className="text-xl font-semibold leading-tight text-gray-800">
                    Chat Boat
                </h2>
            }
        >
            <Head title="Chat Boat" />
            <div className="w-[70%] m-[auto] flex flex-col h-screen p-4 bg-gray-100">
                <div className="flex-1 overflow-y-auto mb-4 bg-white p-4 rounded shadow">
                    {messages.map((msg, idx) => (
                        <div
                            key={idx}  // Assuming each message has a unique 'id'
                            className={`mb-2 p-2 rounded max-w-xs ${msg.user === auth.user.name ? 'ml-auto bg-blue-500 text-white' : 'mr-auto bg-gray-300'}`}
                        >
                            {/* <div className="flex justify-between items-center">
                            <span className="font-bold">{msg.user}:</span>
                            {msg.user === auth.user.name && (
                                <button
                                    className="text-red-500 text-sm"
                                    onClick={() => handleDelete(msg.id)}
                                >
                                    Delete
                                </button>
                            )}
                        </div> */}
                            <div>{msg.content}</div>
                        </div>
                    ))}
                    <div ref={messagesEndRef} />
                </div>

                <form onSubmit={handleSend} className="flex gap-2">
                    <input
                        type="text"
                        className="flex-1 border rounded p-2"
                        placeholder="Type your message..."
                        value={data.content}
                        onChange={(e) => setData('content', e.target.value)}
                    />
                    <button type="submit" className="bg-blue-500 text-white px-4 py-2 rounded">
                        Send
                    </button>
                </form>
            </div>
        </AuthenticatedLayout>
    );
}
