<?php

use App\Http\Controllers\CustomerController;
use App\Http\Controllers\FollowUpController;
use App\Http\Controllers\ProfileController;
use App\Http\Middleware\EmailVarifyMiddleware;
use Illuminate\Foundation\Application;
use App\Http\Controllers\SocialAuthController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ChatController;
use Inertia\Inertia;

Route::get('/', function () {
    return Inertia::render('Welcome', [
        'canLogin' => Route::has('login'),
        'canRegister' => Route::has('register'),
        'laravelVersion' => Application::VERSION,
        'phpVersion' => PHP_VERSION,
    ]);
});

// Route::get('/dashboard', function () {
//     return Inertia::render('Dashboard');
// })->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware(['auth', 'verified'])->group(function () {

    Route::get('/customers', [CustomerController::class, 'index'])->name('customers');
    Route::post('/customers', [CustomerController::class, 'store'])->name('customers.store');
    Route::put('/customers/{id}', [CustomerController::class, 'update'])->name('customers.update');
    Route::post('/customers/delete/{id}', [CustomerController::class, 'delete'])->name('customers.delete');

    Route::get('/dashboard', [FollowUpController::class, 'index'])->name('dashboard');;
    Route::post('/followups', [FollowUpController::class, 'store'])->name('followups.store');
    Route::post('/followups/update/{id}', [FollowUpController::class, 'update'])->name('followups.update');
    Route::post('/followups/{id}', [FollowUpController::class, 'destroy'])->name('followups.destroy');

    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');

    Route::get('/chat', [ChatController::class, 'index'])->name('chat');
    Route::post('/messages', [ChatController::class, 'send'])->name('messages');
    Route::post('/messages/delete/{id}', [ChatController::class, 'delete'])->name('delete');
});


Route::get('/auth/{provider}', [SocialAuthController::class, 'redirect'])->name('social.redirect');
Route::get('/auth/{provider}/callback', [SocialAuthController::class, 'callback'])->name('social.callback');

require __DIR__ . '/auth.php';
